from flask import render_template, flash
from flask import Flask
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField
from wtforms.fields.html5 import EmailField
from wtforms.validators import DataRequired
import sqlite3 as lite


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandex_lyceum_secret_key'


class LoginForm(FlaskForm):
    search = StringField('')
    submit_search = SubmitField('Найти')
    submit_registration = SubmitField('Войти или зарегистрироваться')
    submit_plant = SubmitField('Добавить растение')


class Entrance(FlaskForm):
    password = PasswordField('Пароль', validators=[DataRequired()])
    username = StringField('Имя пользователя', validators=[DataRequired()])
    submit = SubmitField('Войти')
    submit1 = SubmitField('Зарегистрироваться')


class RegisterForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    password_again = PasswordField('Повторите пароль', validators=[DataRequired()])
    name = StringField('Имя пользователя', validators=[DataRequired()])
    about = TextAreaField("Немного о себе")
    submit = SubmitField('Войти')


@app.route('/home_registration/', methods=['GET', 'POST'])
def entrance():
    conn = lite.connect("people.db")
    cursor = conn.cursor()
    form = RegisterForm()

    cursor.execute("""INSERT INTO people
                      VALUES (?, ?, ?, ?,)""", (form.name.data, form.password.data, form.email.data, form.about.data)
                   )
    conn.commit()


@app.route('/', methods=['GET', 'POST'])
def home():
    form = LoginForm()
    return render_template('page_with_registration.html', title='Найди растение', form=form)


@app.route('/search/', methods=['GET', 'POST'])
def plant_search():
    form = LoginForm()
    con = lite.connect('plant.db')
    a = form.search.data
    with con:
        cur = con.cursor()
        result = cur.execute("""SELECT * FROM plants
                        WHERE name == ?""", (a,)).fetchall()
    if len(result) > 0:
        return render_template('prob2.html', title='Найди растение',
                               Name_plants=result[0][0], Lat_name=result[0][1], Watering=result[0][2],
                               Temperature=result[0][3], Lighting=result[0][4], Landing=result[0][5],
                               Soil=result[0][6], About=result[0][7], form=form)
    else:
        flash('Растение не найдено', category='error')
        return render_template('page_with_registration.html', title='Найди растение', form=form)


@app.route('/registration/', methods=['GET', 'POST'])
def registration():
    form = Entrance()
    return render_template('reg.html', title='Найди растение', form=form)


@app.route('/creature/', methods=['GET', 'POST'])
def Creature():
    form = RegisterForm()
    return render_template('creature.html', title='Найди растение', form=form)


class Add_a_plant(FlaskForm):
    name = StringField('Название растения')
    lat_name = StringField('Латинское название')
    watering = TextAreaField("Полив")
    temperature = TextAreaField("Температура")
    lighting = TextAreaField("Освещение")
    landing = TextAreaField("Посадка")
    soil = TextAreaField("Грунт")
    about = TextAreaField("Описание")
    submit = SubmitField('Добавить')


@app.route('/add_a_plant/', methods=['GET', 'POST'])
def add_a_plant():

    form = Add_a_plant()
    return render_template('add_plant.html', title='Найди растение', form=form)


@app.route('/a_plant/', methods=['GET', 'POST'])
def plant():
    form = LoginForm()
    return render_template('page_with_registration.html', title='Найди растение', form=form)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
